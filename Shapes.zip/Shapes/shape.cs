using System;

namespace Shapes;
abstract class Shape {
    public abstract double getArea();
}